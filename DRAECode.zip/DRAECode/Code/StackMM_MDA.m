function [allhx, Ws] = StackMM_MDA(xx,parameter)

% xx : dxn input
prevhx = xx;
allhx = [];
Ws={};
for layer = 1:parameter.layers
%     	disp(['layer:',num2str(parameter.layers)])
% 	tic
	[newhx, W] = MM_MDA(prevhx,parameter);
	Ws{layer} = W;
% 	toc
	allhx = [allhx; newhx];
%     allhx = newhx;
	prevhx = newhx;
end
