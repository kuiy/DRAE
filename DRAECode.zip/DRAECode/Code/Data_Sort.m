 function [New_src_X,New_label] = Data_Sort (src_X,src_labels)
    Num_Class = length(unique(src_labels));
    lables = unique(src_labels);
    New_src_X = [];
    New_label = [];
    for iter_class = 1: Num_Class
        index = find(src_labels==lables(iter_class));
        New_src_X = [New_src_X,src_X(:,index)];
        New_label = [New_label;src_labels(index)];
    end
end